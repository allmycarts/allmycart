# Grocery Comparator

A web app for comparing grocery products across stores, similar to travel comparison sites, with filter options.

## Features

- Compare grocery products across multiple stores
- Filter by price, brand, category, ratings, and more
- Responsive web design

## Getting Started

1. Clone this repo
2. Run `npm install`
3. Run `npm start`