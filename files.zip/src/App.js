import React, { useState } from 'react';
import FilterBar from './components/FilterBar';
import ProductList from './components/ProductList';
import productsData from './data/products.json';

function App() {
  const [filters, setFilters] = useState({ brand: '', category: '', store: '' });

  const filteredProducts = productsData.filter(p => 
    (!filters.brand || p.brand === filters.brand) &&
    (!filters.category || p.category === filters.category) &&
    (!filters.store || p.store === filters.store)
  );

  return (
    <div>
      <h1>Grocery Comparator</h1>
      <FilterBar filters={filters} setFilters={setFilters} products={productsData} />
      <ProductList products={filteredProducts} />
    </div>
  );
}

export default App;