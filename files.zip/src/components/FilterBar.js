import React from 'react';

function FilterBar({ filters, setFilters, products }) {
  const brands = Array.from(new Set(products.map(p => p.brand)));
  const categories = Array.from(new Set(products.map(p => p.category)));
  const stores = Array.from(new Set(products.map(p => p.store)));

  return (
    <div>
      <select value={filters.brand} onChange={e => setFilters(f => ({ ...f, brand: e.target.value }))}>
        <option value="">All Brands</option>
        {brands.map(b => <option key={b} value={b}>{b}</option>)}
      </select>
      <select value={filters.category} onChange={e => setFilters(f => ({ ...f, category: e.target.value }))}>
        <option value="">All Categories</option>
        {categories.map(c => <option key={c} value={c}>{c}</option>)}
      </select>
      <select value={filters.store} onChange={e => setFilters(f => ({ ...f, store: e.target.value }))}>
        <option value="">All Stores</option>
        {stores.map(s => <option key={s} value={s}>{s}</option>)}
      </select>
    </div>
  );
}

export default FilterBar;