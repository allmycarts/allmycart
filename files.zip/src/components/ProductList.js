import React from 'react';

function ProductList({ products }) {
  return (
    <table>
      <thead>
        <tr>
          <th>Name</th>
          <th>Brand</th>
          <th>Category</th>
          <th>Store</th>
          <th>Price</th>
        </tr>
      </thead>
      <tbody>
        {products.map((p, idx) => (
          <tr key={idx}>
            <td>{p.name}</td>
            <td>{p.brand}</td>
            <td>{p.category}</td>
            <td>{p.store}</td>
            <td>${p.price.toFixed(2)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default ProductList;